var max = 10;
for (var index = 0; index < max; index++) {
  console.log(index);
}
